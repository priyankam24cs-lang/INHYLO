import 'package:flutter/material.dart';

// INHYLO screens
import 'login_screen.dart';
import 'create_account_screen.dart';
import 'home_screen.dart';
import 'reports_screen.dart';
import 'account_screen.dart';

void main() {
  runApp(const InhyloApp());
}

class InhyloApp extends StatelessWidget {
  const InhyloApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'INHYLO',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: const Color(0xFFFFD84D),
        scaffoldBackgroundColor: Colors.white,
        fontFamily: 'Arial',
      ),
      home: const LoginScreen(),
      routes: {
        '/login': (context) => const LoginScreen(),
        '/create-account': (context) => const CreateAccountScreen(),
        '/home': (context) => const HomeScreen(),
        '/reports': (context) => const ReportsScreen(),
        '/account': (context) => const AccountScreen(),
      },
    );
  }
}